
#ifndef Balance_h
#define Balance_h

#include "avr/pgmspace.h"
#include "arduino.h"

#include <TimerThree.h>
#include <Wire.h>
 
class Balance
{ 
   float Err=0, intErr=0, deg=0 ;    
   bool dde=0;
   public:
    
    void Motor_Init();
    void Gyro_Init();
    void Intt_Init();
    void Motor(int v1, int v2);  
    void Gyro_Get(int16_t* AcX, int16_t* AcY, int16_t* AcZ, int16_t* GyX, int16_t* GyY, int16_t* GyZ);
    float Gfilter(float acd, int GyY,  float k1, float k2);
    
  private:
      

};

#endif
