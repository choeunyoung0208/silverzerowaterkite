
#include "Balance.h"
#include "Arduino.h"

  
 
void Balance::Motor_Init()
{  pinMode(4,OUTPUT);  pinMode(5,OUTPUT);  // LED
   pinMode(6,OUTPUT);  pinMode(7,OUTPUT);
   pinMode(8,OUTPUT);  pinMode(9,OUTPUT);
   pinMode(2,INPUT_PULLUP); pinMode(3,INPUT_PULLUP);  // Interrupt A
   pinMode(18,INPUT_PULLUP); pinMode(19,INPUT_PULLUP);  // Interrupt A
  
   TCCR4A=0b10001001;
   TCCR4B=0b00001001;
   OCR4A=0;   OCR4C=0; 
}

void Balance::Motor(int v1, int v2)
{ if (v1<0) {digitalWrite(7,LOW);  v1=abs(v1);} else {digitalWrite(7,HIGH);}
  if (v2<0) {digitalWrite(9,HIGH); v2=abs(v2);} else {digitalWrite(9,LOW);}
  if (v1>255) {v1=255;} if (v2>255) {v2=255;}
  OCR4A=v1;   OCR4C=v2; 
}

void Balance::Gyro_Init()
{
  Wire.begin();   Wire.setClock(400000);                // Wire 라이브러리 초기화, 통신속도 400k
  Wire.beginTransmission(0x68);  Wire.write(0x6B);      // MPU-6050 시작 모드로
  Wire.write(0);       Wire.endTransmission(true); 
  Wire.beginTransmission(0x68);     Wire.write(0x1A);   // DLPF_CFG 세팅 0b00000xxx
  Wire.write(0b00000000); Wire.endTransmission(true);   // 0:260 1:180 2:95 3:45 Hz  
  Wire.beginTransmission(0x68);     Wire.write(0x1B);   // 자이로 세팅 0b000xx000
  Wire.write(0b00010000); Wire.endTransmission(true);   // 0:250 1:500 2:1000 3:2000 deg
  Wire.beginTransmission(0x68);     Wire.write(0x1C);   // 가속도 세팅 0b000xx000
  Wire.write(0b00010000); Wire.endTransmission(true);   // 0:2g 1:4g 2:8g 3:16g   
}


void Balance::Gyro_Get(int16_t* AcX, int16_t* AcY, int16_t* AcZ, int16_t* GyX, int16_t* GyY, int16_t* GyZ)
{
  Wire.beginTransmission(0x68);           // 전송시작
  Wire.write(0x3B);                       // register 0x3B (ACCEL_XOUT_H), 큐에 Data 기록
  Wire.endTransmission(false);            // 연결유지
  Wire.requestFrom(0x68,14,true);         // MPU에 14 byte(7 data) 요청
  int16_t Tmp;  
    *AcX=(Wire.read()<<8|Wire.read());         // 0x3B (ACCEL_XOUT_H) & 0x3C (ACCEL_XOUT_L)    
    *AcY=(Wire.read()<<8|Wire.read());         // 0x3D (ACCEL_YOUT_H) & 0x3E (ACCEL_YOUT_L)
    *AcZ=(Wire.read()<<8|Wire.read());         // 0x3F (ACCEL_ZOUT_H) & 0x40 (ACCEL_ZOUT_L)
     Tmp=(Wire.read()<<8|Wire.read());         // 0x41 (TEMP_OUT_H) & 0x42 (TEMP_OUT_L)
    *GyX=(Wire.read()<<8|Wire.read());     // 0x43 (GYRO_XOUT_H) & 0x44 (GYRO_XOUT_L)
    *GyY=(Wire.read()<<8|Wire.read());     // 0x45 (GYRO_YOUT_H) & 0x46 (GYRO_YOUT_L)
    *GyZ=(Wire.read()<<8|Wire.read());     // 0x47 (GYRO_ZOUT_H) & 0x48 (GYRO_ZOUT_L)
}

float Balance::Gfilter(float acd, int GyY,  float k1, float k2)
{
    if (dde==0)  {deg=acd; dde=1;}
    else { Err=acd-deg;     intErr=intErr + Err*0.01;
           deg=deg + ( k1*Err + k2*intErr - GyY*0.0305 )*0.01;  }

    return deg;       
           
 
}
